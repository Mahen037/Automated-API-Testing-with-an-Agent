import { test, expect, APIResponse } from '@playwright/test';

const BASE_URL = process.env.API_BASE_URL || 'http://localhost:6405';

// Helper function to simulate user login and return authenticated context.
// For the purpose of these tests, we assume that successful login
// establishes a session handled by Playwright's request context.
async function loginAndGetAuthenticatedContext(username = `authuser_${Date.now()}`, password = 'authpassword') {
    const authRequest = await test.request.newContext();

    // First, ensure the user exists for login
    await authRequest.post(`${BASE_URL}/add_user`, {
        form: {
            username: username,
            password: password,
            confirm_password: password,
        },
        maxRedirects: 0
    });

    const loginResponse = await authRequest.post(`${BASE_URL}/login_user`, {
        form: {
            username: username,
            password: password,
        },
        maxRedirects: 0
    });

    expect(loginResponse.status()).toBe(302);
    expect(loginResponse.headers().location).toBe('/');
    // The 'authRequest' context now holds the session cookies
    return authRequest;
}


test.describe('Contacts Service', () => {

    test('GET /contacts - Retrieves a list of contacts in JSON format', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/contacts`);
        expect(response.status()).toBe(200);
        expect(response.headers()['content-type']).toContain('application/json');
        const json = await response.json();
        expect(json).toHaveProperty('contacts');
        expect(Array.isArray(json.contacts)).toBe(true);
        // TODO: More specific assertions on the structure of contact objects if schema is known
    });

    test('GET / - Renders the home page with a list of contacts', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Contact List</title>');
        // TODO: Verify presence of contact data on the page
    });

    test('GET /create - Renders the create contact page', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/create`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Create Contact</title>');
    });

    test('POST /add_contact - Happy path: Adds a new contact successfully', async ({ request }) => {
        const response = await request.post(`${BASE_URL}/add_contact`, {
            form: {
                firstName: 'John',
                lastName: 'Doe',
                email: `john.doe.${Date.now()}@example.com`,
                phone: '123-456-7890',
                street: '1600 Amphitheatre Pkwy',
                city: 'Mountain View',
                state: 'CA',
                country: 'USA',
                zip: '94043',
            },
            maxRedirects: 0
        });

        expect(response.status()).toBe(302);
        expect(response.headers().location).toBe('/');
        // TODO: Verify the contact was actually added by fetching /contacts
    });

    test('POST /add_contact - Negative path: Invalid address (geocode failure)', async ({ request }) => {
        const response = await request.post(`${BASE_URL}/add_contact`, {
            form: {
                firstName: 'Invalid',
                lastName: 'Address',
                email: `invalid.address.${Date.now()}@example.com`,
                phone: '111-222-3333',
                street: 'NonExistent Street 123',
                city: 'Imaginary City',
                state: 'ZZ',
                country: 'Neverland',
                zip: '00000',
            },
        });

        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('Address not found! Try Again.');
        expect(await response.text()).toContain('<title>Create Contact</title>');
    });

    test('GET /:id - Renders contact information page for a specific contact', async ({ request }) => {
        // First, add a contact to get an ID
        const addContactResponse = await request.post(`${BASE_URL}/add_contact`, {
            form: {
                firstName: 'View',
                lastName: 'Contact',
                email: `view.contact.${Date.now()}@example.com`,
                phone: '987-654-3210',
                street: '1 Infinite Loop',
                city: 'Cupertino',
                state: 'CA',
                country: 'USA',
                zip: '95014',
            },
            maxRedirects: 0
        });

        // Assuming a redirect to '/' after adding, we need to find the contact ID
        // This is a simplification; ideally, the POST /add_contact would return the ID.
        // For now, we'll try to fetch all contacts and find the newly added one.
        // TODO: Improve this by having POST /add_contact return the ID or querying the DB directly in tests
        const contactsResponse = await request.get(`${BASE_URL}/contacts`);
        const contactsJson = await contactsResponse.json();
        const newContact = contactsJson.contacts.find((c: any) => c.email.includes('view.contact.'));
        expect(newContact).toBeDefined();
        const contactId = newContact.id;

        const response = await request.get(`${BASE_URL}/${contactId}`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Contact Info</title>');
        expect(await response.text()).toContain(newContact.firstName);
        expect(await response.text()).toContain(newContact.lastName);
    });

    test('POST /:id/update_contact - Unauthorized: Update contact without login', async ({ request }) => {
        // Attempt to update a non-existent contact to trigger auth check first
        const contactId = 99999; // A dummy ID
        const response = await request.post(`${BASE_URL}/${contactId}/update_contact`, {
            form: {
                firstName: 'Unauthorized',
                lastName: 'User',
                email: 'unauthorized@example.com',
                phone: '111-111-1111',
                street: '123 Main St',
                city: 'Anytown',
                state: 'NY',
                country: 'USA',
                zip: '10001',
            },
            maxRedirects: 0
        });

        expect(response.status()).toBe(401);
        expect(await response.text()).toContain('Not authorized');
    });

    test('POST /:id/update_contact - Happy path: Update an existing contact with login', async ({ request }) => {
        const authRequest = await loginAndGetAuthenticatedContext();

        // First, add a contact using the authenticated context to get an ID
        const addContactResponse = await authRequest.post(`${BASE_URL}/add_contact`, {
            form: {
                firstName: 'Update',
                lastName: 'Me',
                email: `update.me.${Date.now()}@example.com`,
                phone: '555-555-5555',
                street: '789 Pine St',
                city: 'Oldtown',
                state: 'GA',
                country: 'USA',
                zip: '30303',
            },
            maxRedirects: 0
        });
        expect(addContactResponse.status()).toBe(302); // Should redirect after add

        // Fetch contacts to find the ID of the newly added contact
        const contactsResponse = await authRequest.get(`${BASE_URL}/contacts`);
        const contactsJson = await contactsResponse.json();
        const contactToUpdate = contactsJson.contacts.find((c: any) => c.email.includes('update.me.'));
        expect(contactToUpdate).toBeDefined();
        const contactId = contactToUpdate.id;

        const updatedFirstName = 'UpdatedName';
        const response = await authRequest.post(`${BASE_URL}/${contactId}/update_contact`, {
            form: {
                firstName: updatedFirstName,
                lastName: contactToUpdate.lastName,
                email: contactToUpdate.email,
                phone: contactToUpdate.phone,
                street: contactToUpdate.street,
                city: contactToUpdate.city,
                state: contactToUpdate.state,
                country: contactToUpdate.country,
                zip: contactToUpdate.zip,
            },
            maxRedirects: 0
        });

        expect(response.status()).toBe(302);
        expect(response.headers().location).toBe('/');

        // Verify the update by fetching the contact again
        const updatedContactPage = await authRequest.get(`${BASE_URL}/${contactId}`);
        expect(await updatedContactPage.text()).toContain(updatedFirstName);

        await authRequest.dispose(); // Clean up the authenticated context
    });

    test('POST /:id/update_contact - Negative path: Update with invalid address (geocode failure) with login', async ({ request }) => {
        const authRequest = await loginAndGetAuthenticatedContext();

        // First, add a contact using the authenticated context to get an ID
        const addContactResponse = await authRequest.post(`${BASE_URL}/add_contact`, {
            form: {
                firstName: 'GeocodeFail',
                lastName: 'Update',
                email: `geocode.fail.${Date.now()}@example.com`,
                phone: '555-123-4567',
                street: '123 Valid Street',
                city: 'Valid City',
                state: 'VA',
                country: 'USA',
                zip: '22202',
            },
            maxRedirects: 0
        });
        expect(addContactResponse.status()).toBe(302);

        // Fetch contacts to find the ID
        const contactsResponse = await authRequest.get(`${BASE_URL}/contacts`);
        const contactsJson = await contactsResponse.json();
        const contactToUpdate = contactsJson.contacts.find((c: any) => c.email.includes('geocode.fail.'));
        expect(contactToUpdate).toBeDefined();
        const contactId = contactToUpdate.id;

        const response = await authRequest.post(`${BASE_URL}/${contactId}/update_contact`, {
            form: {
                firstName: contactToUpdate.firstName,
                lastName: contactToUpdate.lastName,
                email: contactToUpdate.email,
                phone: contactToUpdate.phone,
                street: 'Invalid Street XYZ',
                city: 'NonExistentville',
                state: 'ZZ',
                country: 'NoWhere',
                zip: '00000',
            },
        });

        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('Address not found! Try Again.');
        expect(await response.text()).toContain('<title>Contact Info</title>'); // Expect to stay on contact info page
        await authRequest.dispose();
    });

    test('POST /:id/remove_contact - Unauthorized: Remove contact without login', async ({ request }) => {
        // Attempt to remove a non-existent contact to trigger auth check first
        const contactId = 99999; // A dummy ID
        const response = await request.post(`${BASE_URL}/${contactId}/remove_contact`, {
            maxRedirects: 0
        });

        expect(response.status()).toBe(401);
        expect(await response.text()).toContain('Not authorized');
    });

    test('POST /:id/remove_contact - Happy path: Remove an existing contact with login', async ({ request }) => {
        const authRequest = await loginAndGetAuthenticatedContext();

        // First, add a contact using the authenticated context to get an ID
        const addContactResponse = await authRequest.post(`${BASE_URL}/add_contact`, {
            form: {
                firstName: 'Remove',
                lastName: 'Me',
                email: `remove.me.${Date.now()}@example.com`,
                phone: '777-777-7777',
                street: '456 Oak Ave',
                city: 'Freetown',
                state: 'TX',
                country: 'USA',
                zip: '77777',
            },
            maxRedirects: 0
        });
        expect(addContactResponse.status()).toBe(302); // Should redirect after add

        // Fetch contacts to find the ID of the newly added contact
        const contactsResponse = await authRequest.get(`${BASE_URL}/contacts`);
        const contactsJson = await contactsResponse.json();
        const contactToRemove = contactsJson.contacts.find((c: any) => c.email.includes('remove.me.'));
        expect(contactToRemove).toBeDefined();
        const contactId = contactToRemove.id;

        const response = await authRequest.post(`${BASE_URL}/${contactId}/remove_contact`, {
            maxRedirects: 0
        });

        expect(response.status()).toBe(302);
        expect(response.headers().location).toBe('/');

        // Verify the contact was removed by trying to fetch its page (expecting a redirect or not found)
        // Since the current app logic for GET /:id seems to render 'contact_info' even if contact[0] is undefined,
        // we'll rely on checking the /contacts endpoint for absence.
        const allContactsAfterRemoval = await authRequest.get(`${BASE_URL}/contacts`);
        const allContactsJson = await allContactsAfterRemoval.json();
        const removedContactStillExists = allContactsJson.contacts.some((c: any) => c.id === contactId);
        expect(removedContactStillExists).toBe(false);

        await authRequest.dispose();
    });
});
