import { test, expect, APIResponse } from '@playwright/test';

// Define a base URL for the API.
// This can be set as an environment variable or hardcoded for testing purposes.
const BASE_URL = process.env.API_BASE_URL || 'http://localhost:6405';

// Helper function to simulate user login and return authenticated context or token.
// TODO: Implement actual login logic based on the application's authentication flow
// For now, it will simulate a successful login by returning a generic response.
async function loginHelper(request: any, username?: string, password?: string): Promise<APIResponse | null> {
    if (!username || !password) {
        console.warn('Login helper called without username or password. This might not result in a valid session.');
        return null;
    }
    const loginResponse = await request.post(`${BASE_URL}/login_user`, {
        form: {
            username: username,
            password: password,
        },
        // We expect a redirect on successful login
        maxRedirects: 0 // Do not follow redirects
    });
    // For a successful login, the application redirects to '/', so we expect a 302
    if (loginResponse.status() === 302) {
        // In a real scenario, you might want to extract session cookies here
        // For Playwright, the context often handles cookies automatically if you use `await request.newContext()`.
        return loginResponse;
    } else {
        console.error(`Login failed for user ${username}. Status: ${loginResponse.status()}`);
        return null;
    }
}


test.describe('Accounts Service', () => {
    test('POST /add_user - Happy path: Create a new user successfully', async ({ request }) => {
        // Generate unique username to avoid conflicts
        const username = `testuser_${Date.now()}`;
        const password = 'testpassword';

        const response = await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password,
            },
            maxRedirects: 0 // Do not follow redirects to check for 302
        });

        expect(response.status()).toBe(302);
        expect(response.headers().location).toBe('/');
    });

    test('POST /add_user - Negative path: Passwords do not match', async ({ request }) => {
        const username = `testuser_mismatch_${Date.now()}`;
        const password = 'testpassword';
        const confirmPassword = 'differentpassword';

        const response = await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: confirmPassword,
            },
        });

        expect(response.status()).toBe(200);
        // TODO: Verify actual HTML content for the error message
        expect(await response.text()).toContain('Passwords do not match!');
    });

    test('POST /add_user - Negative path: Username already exists', async ({ request }) => {
        // First, create a user
        const username = `existinguser_${Date.now()}`;
        const password = 'testpassword';

        await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password,
            },
            maxRedirects: 0
        });

        // Attempt to create the same user again
        const response = await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password,
            },
        });

        expect(response.status()).toBe(200);
        // TODO: Verify actual HTML content for the error message
        expect(await response.text()).toContain('This username/account already exists!');
    });

    // TODO: Add tests for missing required fields (username, password, confirm_password)
    // Assuming the application returns 200 with an error message on the signup page.
    test('POST /add_user - Negative path: Missing username', async ({ request }) => {
        const password = 'testpassword';
        const response = await request.post(`${BASE_URL}/add_user`, {
            form: {
                // username: missing
                password: password,
                confirm_password: password,
            },
        });
        expect(response.status()).toBe(200);
        // TODO: Verify exact error message in HTML for missing username
        expect(await response.text()).toContain('Sign Up'); // Expect to stay on signup page
    });

    test('POST /login_user - Happy path: Login with valid credentials', async ({ request }) => {
        // First, ensure a user exists for login
        const username = `loginuser_${Date.now()}`;
        const password = 'loginpassword';
        await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password,
            },
            maxRedirects: 0
        });

        const response = await request.post(`${BASE_URL}/login_user`, {
            form: {
                username: username,
                password: password,
            },
            maxRedirects: 0
        });

        expect(response.status()).toBe(302);
        expect(response.headers().location).toBe('/');
        // TODO: Verify session cookie or other authentication mechanism if exposed
    });

    test('POST /login_user - Negative path: Login with invalid password', async ({ request }) => {
        // First, ensure a user exists for login
        const username = `invalidpassuser_${Date.now()}`;
        const password = 'validpassword';
        await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password,
            },
            maxRedirects: 0
        });

        const response = await request.post(`${BASE_URL}/login_user`, {
            form: {
                username: username,
                password: 'wrongpassword',
            },
        });

        expect(response.status()).toBe(200);
        // TODO: Verify actual HTML content for the error message
        expect(await response.text()).toContain('Invalid account credentials, try again!');
        expect(await response.text()).toContain('Login'); // Expect to stay on login page
    });

    test('POST /login_user - Negative path: Login with non-existent username', async ({ request }) => {
        const response = await request.post(`${BASE_URL}/login_user`, {
            form: {
                username: `nonexistentuser_${Date.now()}`,
                password: 'anypassword',
            },
        });

        expect(response.status()).toBe(200);
        // TODO: Verify actual HTML content for the error message
        expect(await response.text()).toContain('Invalid account credentials, try again!');
        expect(await response.text()).toContain('Login'); // Expect to stay on login page
    });

    test('GET /login - Renders the login page', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/login`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Login</title>');
    });

    test('GET /sign_up - Renders the sign-up page', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/sign_up`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Sign Up</title>');
    });

    test('GET /logout - Logs out the current user and redirects', async ({ request }) => {
        // First, log in a user to establish a session
        const username = `logoutuser_${Date.now()}`;
        const password = 'logoutpassword';
        await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password,
            },
            maxRedirects: 0
        });
        await request.post(`${BASE_URL}/login_user`, {
            form: {
                username: username,
                password: password,
            },
            maxRedirects: 0
        });

        const response = await request.get(`${BASE_URL}/logout`, {
            maxRedirects: 0 // Do not follow redirects
        });

        expect(response.status()).toBe(302);
        expect(response.headers().location).toBe('/');
        // TODO: Verify session invalidation (e.g., check for absence of session cookie)
    });
});
