import { test, expect, APIRequestContext } from '@playwright/test';

const BASE_URL = 'http://localhost:6405';

// Helper function to login and get a session cookie or token
async function login(request: APIRequestContext, username = 'testuser', password = 'testpassword') {
    await request.post(`${BASE_URL}/add_user`, {
        form: {
            username: username,
            password: password,
            confirm_password: password
        }
    });

    const loginResponse = await request.post(`${BASE_URL}/login_user`, {
        form: {
            username: username,
            password: password
        }
    });
    // Assuming successful login redirects to / and sets a session cookie
    // Playwright's request context should automatically handle cookies from redirects
    return loginResponse;
}

test.describe('main-service API tests', () => {

    test('POST /add_user - Successful user creation', async ({ request }) => {
        const username = `user_${Date.now()}`;
        const password = 'password123';
        const response = await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password
            }
        });
        expect(response.status()).toBe(200); // Expect a redirect
        expect(response.url()).toBe(`${BASE_URL}/`); // Should redirect to home
    });

    test('POST /add_user - Passwords do not match', async ({ request }) => {
        const username = `user_${Date.now()}`;
        const response = await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: 'password123',
                confirm_password: 'differentpassword'
            }
        });
        expect(response.status()).toBe(200); // Renders sign_up page
        expect(await response.text()).toContain('Passwords do not match!');
    });

    test('POST /add_user - Username already exists', async ({ request }) => {
        const username = `existinguser_${Date.now()}`;
        const password = 'password123';
        // First, create the user
        await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password
            }
        });

        // Try to create the same user again
        const response = await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password
            }
        });
        expect(response.status()).toBe(200); // Renders sign_up page
        expect(await response.text()).toContain('This username/account already exists!');
    });

    test('POST /login_user - Successful login', async ({ request }) => {
        const username = `loginuser_${Date.now()}`;
        const password = 'loginpassword123';
        await request.post(`${BASE_URL}/add_user`, {
            form: {
                username: username,
                password: password,
                confirm_password: password
            }
        });

        const response = await request.post(`${BASE_URL}/login_user`, {
            form: {
                username: username,
                password: password
            }
        });
        expect(response.status()).toBe(200); // Expect a redirect
        expect(response.url()).toBe(`${BASE_URL}/`); // Should redirect to home
    });

    test('POST /login_user - Invalid credentials', async ({ request }) => {
        const response = await request.post(`${BASE_URL}/login_user`, {
            form: {
                username: 'nonexistentuser',
                password: 'wrongpassword'
            }
        });
        expect(response.status()).toBe(200); // Renders login page
        expect(await response.text()).toContain('Invalid account credentials, try again!');
    });

    test('GET /login - Renders login page', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/login`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Login</title>'); // Check for a specific element on the login page
    });

    test('GET /sign_up - Renders sign-up page', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/sign_up`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Sign Up</title>'); // Check for a specific element on the sign-up page
    });

    test('GET /logout - Successful logout', async ({ request }) => {
        const username = `logoutuser_${Date.now()}`;
        const password = 'logoutpassword123';
        await login(request, username, password); // Log in a user first

        const response = await request.get(`${BASE_URL}/logout`);
        expect(response.status()).toBe(200); // Expect a redirect
        expect(response.url()).toBe(`${BASE_URL}/`); // Should redirect to home
    });

    test('GET / - Renders home page (unauthenticated)', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Contact List</title>');
        // Assert that user data is not present for unauthenticated user
        expect(await response.text()).not.toContain('Welcome,'); // Assuming a welcome message for logged-in users
    });

    test('GET / - Renders home page (authenticated)', async ({ request }) => {
        const username = `homeuser_${Date.now()}`;
        const password = 'homepassword123';
        await login(request, username, password);

        const response = await request.get(`${BASE_URL}/`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Contact List</title>');
        expect(await response.text()).toContain(`Welcome, ${username}`); // Assuming a welcome message for logged-in users
    });

    test('GET /contacts - Returns JSON contacts (unauthenticated)', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/contacts`);
        expect(response.status()).toBe(200);
        const json = await response.json();
        expect(json).toHaveProperty('contacts');
        expect(Array.isArray(json.contacts)).toBe(true);
        expect(json.user).toBeUndefined(); // User should be undefined when not logged in
    });

    test('GET /contacts - Returns JSON contacts (authenticated)', async ({ request }) => {
        const username = `contactsuser_${Date.now()}`;
        const password = 'contactspassword123';
        await login(request, username, password);

        const response = await request.get(`${BASE_URL}/contacts`);
        expect(response.status()).toBe(200);
        const json = await response.json();
        expect(json).toHaveProperty('contacts');
        expect(Array.isArray(json.contacts)).toBe(true);
        expect(json.user).toHaveProperty('username', username);
    });

    test('GET /create - Renders create contact page (unauthenticated)', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/create`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Create Contact</title>');
        expect(await response.text()).not.toContain('Welcome,'); // Should not show user data
    });

    test('GET /create - Renders create contact page (authenticated)', async ({ request }) => {
        const username = `createuser_${Date.now()}`;
        const password = 'createpassword123';
        await login(request, username, password);

        const response = await request.get(`${BASE_URL}/create`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Create Contact</title>');
        expect(await response.text()).toContain(`Welcome, ${username}`); // Should show user data
    });

    test('POST /add_contact - Successful contact creation (authenticated)', async ({ request }) => {
        const username = `addcontactuser_${Date.now()}`;
        const password = 'addcontactpassword123';
        await login(request, username, password);

        const contactData = {
            name: 'John Doe',
            phone: '123-456-7890',
            email: 'john.doe@example.com',
            street: '1600 Amphitheatre Pkwy',
            city: 'Mountain View',
            state: 'CA',
            country: 'USA',
            zip: '94043'
        };

        const response = await request.post(`${BASE_URL}/add_contact`, {
            form: contactData
        });
        expect(response.status()).toBe(200); // Expect a redirect
        expect(response.url()).toBe(`${BASE_URL}/`); // Should redirect to home

        // Verify contact was added (optional, but good for end-to-end)
        const contactsResponse = await request.get(`${BASE_URL}/contacts`);
        const json = await contactsResponse.json();
        const newContact = json.contacts.find((c: any) => c.name === contactData.name && c.email === contactData.email);
        expect(newContact).toBeDefined();
        expect(newContact.formatted_address).toContain('1600 Amphitheatre Pkwy');
    });

    test('POST /add_contact - Address not found (authenticated)', async ({ request }) => {
        const username = `badaddressuser_${Date.now()}`;
        const password = 'badaddresspassword123';
        await login(request, username, password);

        const contactData = {
            name: 'Jane Doe',
            phone: '987-654-3210',
            email: 'jane.doe@example.com',
            street: 'Invalid Street 123',
            city: 'NonExistentCity',
            state: 'XX',
            country: 'InvalidCountry',
            zip: '00000'
        };

        const response = await request.post(`${BASE_URL}/add_contact`, {
            form: contactData
        });
        expect(response.status()).toBe(200); // Renders create_contact page
        expect(await response.text()).toContain('Address not found! Try Again.');
    });

    test('GET /:id - Renders contact info page (authenticated)', async ({ request }) => {
        const username = `infouser_${Date.now()}`;
        const password = 'infopassword123';
        await login(request, username, password);

        const contactData = {
            name: 'Contact Info Test',
            phone: '111-222-3333',
            email: 'info@example.com',
            street: '1 Infinite Loop',
            city: 'Cupertino',
            state: 'CA',
            country: 'USA',
            zip: '95014'
        };
        await request.post(`${BASE_URL}/add_contact`, { form: contactData });

        const contactsResponse = await request.get(`${BASE_URL}/contacts`);
        const json = await contactsResponse.json();
        const newContact = json.contacts.find((c: any) => c.name === contactData.name);
        expect(newContact).toBeDefined();

        const response = await request.get(`${BASE_URL}/${newContact.id}`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('<title>Contact Info</title>');
        expect(await response.text()).toContain(contactData.name);
        expect(await response.text()).toContain(contactData.email);
    });

    test('GET /:id - Invalid contact ID', async ({ request }) => {
        const response = await request.get(`${BASE_URL}/99999999`); // Non-existent ID
        expect(response.status()).toBe(200); // Still renders the page, likely with no contact data
        // Depending on implementation, it might render a generic page or an error message
        // For now, assume it renders the contact_info template without actual data.
        // More specific assertion would depend on the actual rendering logic for missing contacts.
        expect(await response.text()).toContain('<title>Contact Info</title>');
        expect(await response.text()).not.toContain('Contact Info Test'); // Should not contain details of a specific contact
    });

    test('POST /:id/update_contact - Successful contact update (authenticated)', async ({ request }) => {
        const username = `updateuser_${Date.now()}`;
        const password = 'updatepassword123';
        await login(request, username, password);

        const initialContactData = {
            name: 'Initial Contact',
            phone: '555-123-4567',
            email: 'initial@example.com',
            street: '10 Main St',
            city: 'Anytown',
            state: 'NY',
            country: 'USA',
            zip: '10001'
        };
        await request.post(`${BASE_URL}/add_contact`, { form: initialContactData });

        const contactsResponse = await request.get(`${BASE_URL}/contacts`);
        const json = await contactsResponse.json();
        const contactToUpdate = json.contacts.find((c: any) => c.name === initialContactData.name);
        expect(contactToUpdate).toBeDefined();

        const updatedContactData = {
            name: 'Updated Contact Name',
            phone: '555-987-6543',
            email: 'updated@example.com',
            street: '20 Oak Ave',
            city: 'Othertown',
            state: 'CA',
            country: 'USA',
            zip: '90210'
        };

        const response = await request.post(`${BASE_URL}/${contactToUpdate.id}/update_contact`, {
            form: updatedContactData
        });
        expect(response.status()).toBe(200); // Expect a redirect
        expect(response.url()).toBe(`${BASE_URL}/`); // Should redirect to home

        // Verify contact was updated
        const updatedContactsResponse = await request.get(`${BASE_URL}/contacts`);
        const updatedJson = await updatedContactsResponse.json();
        const verifiedContact = updatedJson.contacts.find((c: any) => c.id === contactToUpdate.id);
        expect(verifiedContact).toBeDefined();
        expect(verifiedContact.name).toBe(updatedContactData.name);
        expect(verifiedContact.email).toBe(updatedContactData.email);
        expect(verifiedContact.formatted_address).toContain('20 Oak Ave');
    });

    test('POST /:id/update_contact - Unauthorized access', async ({ request }) => {
        // Attempt to update without logging in or with invalid session
        const contactId = 1; // Assuming a contact with ID 1 exists
        const updatedContactData = {
            name: 'Unauthorized Update',
            phone: '111-111-1111',
            email: 'unauth@example.com',
            street: '123 Fake St',
            city: 'Nowhere',
            state: 'TX',
            country: 'USA',
            zip: '77777'
        };
        const response = await request.post(`${BASE_URL}/${contactId}/update_contact`, {
            form: updatedContactData
        });
        expect(response.status()).toBe(401);
        expect(await response.text()).toContain('Not authorized');
    });

    test('POST /:id/update_contact - Address not found (authenticated)', async ({ request }) => {
        const username = `badupdateaddressuser_${Date.now()}`;
        const password = 'badupdateaddresspassword123';
        await login(request, username, password);

        // Add a contact first
        const initialContactData = {
            name: 'Contact For Bad Update',
            phone: '555-000-0000',
            email: 'badupdate@example.com',
            street: '1 Test St',
            city: 'Testville',
            state: 'TS',
            country: 'USA',
            zip: '11111'
        };
        await request.post(`${BASE_URL}/add_contact`, { form: initialContactData });

        const contactsResponse = await request.get(`${BASE_URL}/contacts`);
        const json = await contactsResponse.json();
        const contactToUpdate = json.contacts.find((c: any) => c.name === initialContactData.name);
        expect(contactToUpdate).toBeDefined();

        const updatedContactData = {
            name: 'Updated Bad Address',
            phone: '555-000-0000',
            email: 'badupdate@example.com',
            street: 'Totally Invalid Street',
            city: 'NonExistentCity',
            state: 'XX',
            country: 'InvalidCountry',
            zip: '00000'
        };

        const response = await request.post(`${BASE_URL}/${contactToUpdate.id}/update_contact`, {
            form: updatedContactData
        });
        expect(response.status()).toBe(200); // Renders contact_info page
        expect(await response.text()).toContain('Address not found! Try Again.');
    });

    test('POST /:id/remove_contact - Successful contact removal (authenticated)', async ({ request }) => {
        const username = `removeuser_${Date.now()}`;
        const password = 'removepassword123';
        await login(request, username, password);

        // Add a contact to remove
        const contactToRemoveData = {
            name: 'Contact To Remove',
            phone: '999-999-9999',
            email: 'remove@example.com',
            street: '30 delete St',
            city: 'Eraseville',
            state: 'CA',
            country: 'USA',
            zip: '90001'
        };
        await request.post(`${BASE_URL}/add_contact`, { form: contactToRemoveData });

        const contactsResponseBefore = await request.get(`${BASE_URL}/contacts`);
        const jsonBefore = await contactsResponseBefore.json();
        const contactToDelete = jsonBefore.contacts.find((c: any) => c.name === contactToRemoveData.name);
        expect(contactToDelete).toBeDefined();

        const response = await request.post(`${BASE_URL}/${contactToDelete.id}/remove_contact`);
        expect(response.status()).toBe(200); // Expect a redirect
        expect(response.url()).toBe(`${BASE_URL}/`); // Should redirect to home

        // Verify contact was removed
        const contactsResponseAfter = await request.get(`${BASE_URL}/contacts`);
        const jsonAfter = await contactsResponseAfter.json();
        const verifiedContact = jsonAfter.contacts.find((c: any) => c.id === contactToDelete.id);
        expect(verifiedContact).toBeUndefined();
    });

    test('POST /:id/remove_contact - Unauthorized access', async ({ request }) => {
        // Attempt to remove without logging in or with invalid session
        const contactId = 1; // Assuming a contact with ID 1 exists
        const response = await request.post(`${BASE_URL}/${contactId}/remove_contact`);
        expect(response.status()).toBe(401);
        expect(await response.text()).toContain('Not authorized');
    });
});
