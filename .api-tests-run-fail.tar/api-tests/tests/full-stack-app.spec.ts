import { test, expect, APIRequestContext } from '@playwright/test';

// Function to generate a unique username
function generateUniqueUsername() {
    return `testuser_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
}

// Function to register a user and return the API context with logged-in session
async function registerAndLogin(request: APIRequestContext, username?: string, password?: string) {
    const user = username || generateUniqueUsername();
    const pass = password || 'password123';
    const confirmPass = pass;

    // Register user
    await request.post('/add_user', {
        form: {
            username: user,
            password: pass,
            confirm_password: confirmPass,
        },
    });

    // Login user
    const loginResponse = await request.post('/login_user', {
        form: {
            username: user,
            password: pass,
        },
    });
    expect(loginResponse.status()).toBe(302); // Redirect on successful login
    return { request, username: user, password: pass };
}


test.describe('Full Stack App API Tests', () => {
    const baseURL = 'http://localhost:6405';
    let loggedInRequest: APIRequestContext;
    let registeredUsername: string;
    let registeredPassword: string;

    test.beforeEach(async ({ request }) => {
        // This will be used for tests that require a logged-in user
        const { request: newRequest, username, password } = await registerAndLogin(request);
        loggedInRequest = newRequest;
        registeredUsername = username;
        registeredPassword = password;
    });

    test('GET / should render the home page', async ({ request }) => {
        const response = await request.get('/');
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('Contact List');
    });

    test('GET /contacts should return a list of contacts and user info for a logged-in user', async () => {
        const response = await loggedInRequest.get('/contacts');
        expect(response.status()).toBe(200);
        const jsonResponse = await response.json();
        expect(jsonResponse).toHaveProperty('contacts');
        expect(Array.isArray(jsonResponse.contacts)).toBe(true);
        expect(jsonResponse).toHaveProperty('user');
        expect(jsonResponse.user.username).toBe(registeredUsername);
    });

    test('GET /contacts should return a list of contacts and no user info for a non-logged-in user', async ({ request }) => {
        const response = await request.get('/contacts');
        expect(response.status()).toBe(200);
        const jsonResponse = await response.json();
        expect(jsonResponse).toHaveProperty('contacts');
        expect(Array.isArray(jsonResponse.contacts)).toBe(true);
        expect(jsonResponse.user).toBeUndefined();
    });

    test('POST /add_user should successfully register and log in a new user', async ({ request }) => {
        const username = generateUniqueUsername();
        const password = 'newpassword123';
        const response = await request.post('/add_user', {
            form: {
                username: username,
                password: password,
                confirm_password: password,
            },
        });
        expect(response.status()).toBe(302); // Redirect to home page on success
        expect(response.headers().location).toBe('/');
    });

    test('POST /add_user should fail if passwords do not match', async ({ request }) => {
        const username = generateUniqueUsername();
        const response = await request.post('/add_user', {
            form: {
                username: username,
                password: 'password123',
                confirm_password: 'differentpassword',
            },
        });
        expect(response.status()).toBe(200); // Renders sign_up page
        expect(await response.text()).toContain('Passwords do not match!');
    });

    test('POST /add_user should fail if username already exists', async () => {
        // User already registered in beforeEach
        const response = await loggedInRequest.post('/add_user', {
            form: {
                username: registeredUsername, // Use the already registered username
                password: registeredPassword,
                confirm_password: registeredPassword,
            },
        });
        expect(response.status()).toBe(200); // Renders sign_up page
        expect(await response.text()).toContain('This username/account already exists!');
    });

    test('POST /login_user should successfully log in an existing user', async () => {
        // User already logged in beforeEach, but we can re-test the login specifically
        const response = await loggedInRequest.post('/login_user', {
            form: {
                username: registeredUsername,
                password: registeredPassword,
            },
        });
        expect(response.status()).toBe(302); // Redirect to home page on success
        expect(response.headers().location).toBe('/');
    });

    test('POST /login_user should fail with invalid credentials', async ({ request }) => {
        const response = await request.post('/login_user', {
            form: {
                username: 'nonexistentuser',
                password: 'wrongpassword',
            },
        });
        expect(response.status()).toBe(200); // Renders login page
        expect(await response.text()).toContain('Invalid account credentials, try again!');
    });

    test('GET /login should render the login page', async ({ request }) => {
        const response = await request.get('/login');
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('Login');
    });

    test('GET /sign_up should render the sign up page', async ({ request }) => {
        const response = await request.get('/sign_up');
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('Sign Up');
    });

    test('GET /logout should log out a user with an active session', async () => {
        const response = await loggedInRequest.get('/logout');
        expect(response.status()).toBe(302); // Redirect to home page
        expect(response.headers().location).toBe('/');
    });

    test('GET /logout should return 401 if no active session', async ({ request }) => {
        const response = await request.get('/logout');
        expect(response.status()).toBe(401);
        expect(await response.text()).toContain('Not authorized');
    });

    test('POST /add_contact should successfully add a new contact for a logged-in user', async () => {
        const response = await loggedInRequest.post('/add_contact', {
            form: {
                name: 'John Doe',
                email: 'john.doe@example.com',
                phone: '123-456-7890',
                street: '1600 Amphitheatre Pkwy',
                city: 'Mountain View',
                state: 'CA',
                country: 'USA',
                zip: '94043',
            },
        });
        expect(response.status()).toBe(302); // Redirect to home page
        expect(response.headers().location).toBe('/');
    });

    test('POST /add_contact should fail if address not found', async () => {
        const response = await loggedInRequest.post('/add_contact', {
            form: {
                name: 'Jane Doe',
                email: 'jane.doe@example.com',
                phone: '098-765-4321',
                street: 'Invalid Street',
                city: 'Invalid City',
                state: 'Invalid State',
                country: 'Invalid Country',
                zip: '00000',
            },
        });
        expect(response.status()).toBe(200); // Renders create_contact page
        expect(await response.text()).toContain('Address not found! Try Again.');
    });

    test('GET /create should render the create contact page', async ({ request }) => {
        const response = await request.get('/create');
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('Create Contact');
    });

    test('GET /:id should render contact info for a valid ID', async () => {
        // First, add a contact to get an ID
        const addContactResponse = await loggedInRequest.post('/add_contact', {
            form: {
                name: 'Test Contact for View',
                email: 'view@example.com',
                phone: '111-222-3333',
                street: '1 Infinite Loop',
                city: 'Cupertino',
                state: 'CA',
                country: 'USA',
                zip: '95014',
            },
            // Since this redirects, we need to follow the redirect to get the contact list and then parse the ID from the HTML or make an API call.
            // For simplicity and because we don't have a direct API to get the ID, we'll assume a new contact gets ID 1 if the DB is fresh, or rely on a GET /contacts after this.
            // A more robust solution would involve scraping the redirected page or having a dedicated API to get the last added contact ID.
        });
        expect(addContactResponse.status()).toBe(302);

        // Fetch contacts to get the ID of the newly added contact
        const contactsResponse = await loggedInRequest.get('/contacts');
        const contactsJson = await contactsResponse.json();
        const newContact = contactsJson.contacts.find((c: any) => c.name === 'Test Contact for View');
        expect(newContact).toBeDefined();

        const response = await loggedInRequest.get(`/${newContact.id}`);
        expect(response.status()).toBe(200);
        expect(await response.text()).toContain('Contact Info');
        expect(await response.text()).toContain('Test Contact for View');
    });

    test('GET /:id should return 404 for an invalid ID format', async ({ request }) => {
        const response = await request.get('/abc'); // Invalid ID format
        expect(response.status()).toBe(404);
    });

    test('POST /:id/update_contact should successfully update a contact for a logged-in user', async () => {
        // First, add a contact to get an ID
        const addContactResponse = await loggedInRequest.post('/add_contact', {
            form: {
                name: 'Contact to Update',
                email: 'update@example.com',
                phone: '111-222-3333',
                street: '123 Old St',
                city: 'Oldville',
                state: 'OS',
                country: 'UK',
                zip: 'OL1 2CD',
            },
        });
        expect(addContactResponse.status()).toBe(302);

        const contactsResponse = await loggedInRequest.get('/contacts');
        const contactsJson = await contactsResponse.json();
        const contactToUpdate = contactsJson.contacts.find((c: any) => c.name === 'Contact to Update');
        expect(contactToUpdate).toBeDefined();

        const updatedName = 'Updated Contact Name';
        const response = await loggedInRequest.post(`/${contactToUpdate.id}/update_contact`, {
            form: {
                name: updatedName,
                email: 'updated@example.com',
                phone: '999-888-7777',
                street: '456 New Rd',
                city: 'Newtown',
                state: 'NY',
                country: 'USA',
                zip: '10001',
            },
        });
        expect(response.status()).toBe(302); // Redirect to home page
        expect(response.headers().location).toBe('/');

        // Verify the update
        const verifyContactsResponse = await loggedInRequest.get('/contacts');
        const verifyContactsJson = await verifyContactsResponse.json();
        const verifiedContact = verifyContactsJson.contacts.find((c: any) => c.id === contactToUpdate.id);
        expect(verifiedContact).toBeDefined();
        expect(verifiedContact.name).toBe(updatedName);
    });

    test('POST /:id/update_contact should return 401 if not authorized', async ({ request }) => {
        // No login for this request
        const response = await request.post('/1/update_contact', { // Use a dummy ID
            form: {
                name: 'Unauthorized Update',
                email: 'unauth@example.com',
                phone: '111-111-1111',
                street: '123 Main St',
                city: 'Anytown',
                state: 'AS',
                country: 'USA',
                zip: '12345',
            },
        });
        expect(response.status()).toBe(401);
        expect(await response.text()).toContain('Not authorized');
    });

    test('POST /:id/update_contact should fail if address not found for a logged-in user', async () => {
        // First, add a contact to get an ID
        const addContactResponse = await loggedInRequest.post('/add_contact', {
            form: {
                name: 'Contact to Update Address',
                email: 'updateaddr@example.com',
                phone: '111-222-3333',
                street: '123 Valid St',
                city: 'Validville',
                state: 'VS',
                country: 'USA',
                zip: '12345',
            },
        });
        expect(addContactResponse.status()).toBe(302);

        const contactsResponse = await loggedInRequest.get('/contacts');
        const contactsJson = await contactsResponse.json();
        const contactToUpdate = contactsJson.contacts.find((c: any) => c.name === 'Contact to Update Address');
        expect(contactToUpdate).toBeDefined();

        const response = await loggedInRequest.post(`/${contactToUpdate.id}/update_contact`, {
            form: {
                name: 'Contact to Update Address',
                email: 'updateaddr@example.com',
                phone: '111-222-3333',
                street: 'Invalid Street For Update',
                city: 'Invalid City For Update',
                state: 'Invalid State For Update',
                country: 'Invalid Country For Update',
                zip: '00000',
            },
        });
        expect(response.status()).toBe(200); // Renders contact_info page
        expect(await response.text()).toContain('Address not found! Try Again.');
    });

    test('POST /:id/update_contact should return 404 for an invalid ID format', async () => {
        const response = await loggedInRequest.post('/abc/update_contact', { // Invalid ID format
            form: {
                name: 'Invalid ID Update',
                email: 'invalidid@example.com',
                phone: '111-111-1111',
                street: '123 Main St',
                city: 'Anytown',
                state: 'AS',
                country: 'USA',
                zip: '12345',
            },
        });
        expect(response.status()).toBe(404);
    });

    test('POST /:id/remove_contact should successfully remove a contact for a logged-in user', async () => {
        // First, add a contact to get an ID
        const addContactResponse = await loggedInRequest.post('/add_contact', {
            form: {
                name: 'Contact to Remove',
                email: 'remove@example.com',
                phone: '555-444-3333',
                street: '789 Delete Ave',
                city: 'Removeville',
                state: 'RV',
                country: 'USA',
                zip: '98765',
            },
        });
        expect(addContactResponse.status()).toBe(302);

        const contactsResponse = await loggedInRequest.get('/contacts');
        const contactsJson = await contactsResponse.json();
        const contactToRemove = contactsJson.contacts.find((c: any) => c.name === 'Contact to Remove');
        expect(contactToRemove).toBeDefined();

        const response = await loggedInRequest.post(`/${contactToRemove.id}/remove_contact`);
        expect(response.status()).toBe(302); // Redirect to home page
        expect(response.headers().location).toBe('/');

        // Verify the removal
        const verifyContactsResponse = await loggedInRequest.get('/contacts');
        const verifyContactsJson = await verifyContactsResponse.json();
        const verifiedContact = verifyContactsJson.contacts.find((c: any) => c.id === contactToRemove.id);
        expect(verifiedContact).toBeUndefined();
    });

    test('POST /:id/remove_contact should return 401 if not authorized', async ({ request }) => {
        // No login for this request
        const response = await request.post('/1/remove_contact'); // Use a dummy ID
        expect(response.status()).toBe(401);
        expect(await response.text()).toContain('Not authorized');
    });

    test('POST /:id/remove_contact should return 404 for an invalid ID format', async () => {
        const response = await loggedInRequest.post('/abc/remove_contact'); // Invalid ID format
        expect(response.status()).toBe(404);
    });
});
